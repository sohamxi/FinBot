import React from 'react';
import { TradingDashboard } from './components/TradingDashboard';
import { BarChart3, Activity, Shield, Settings } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <nav className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-8 h-8 text-blue-500" />
            <span className="text-xl font-bold">ASM Wealth</span>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-gray-700 rounded-lg">
              <BarChart3 className="w-6 h-6" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded-lg">
              <Shield className="w-6 h-6" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded-lg">
              <Settings className="w-6 h-6" />
            </button>
          </div>
        </div>
      </nav>
      <main className="container mx-auto p-4">
        <TradingDashboard />
      </main>
    </div>
  );
}

export default App;