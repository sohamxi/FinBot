import React from 'react';
import { LineChart, Wallet, TrendingUp, AlertTriangle, Activity, BarChart2, Shield, Zap } from 'lucide-react';

export const TradingDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Portfolio Value</p>
              <h3 className="text-2xl font-bold">$2,456,789</h3>
              <span className="text-green-500 text-sm">+2.45%</span>
            </div>
            <LineChart className="w-12 h-12 text-blue-500" />
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Active Positions</p>
              <h3 className="text-2xl font-bold">14</h3>
              <span className="text-gray-400 text-sm">Across 6 strategies</span>
            </div>
            <Wallet className="w-12 h-12 text-purple-500" />
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Today's P&L</p>
              <h3 className="text-2xl font-bold">+$34,567</h3>
              <span className="text-green-500 text-sm">+1.23%</span>
            </div>
            <TrendingUp className="w-12 h-12 text-green-500" />
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Risk Level</p>
              <h3 className="text-2xl font-bold">Moderate</h3>
              <span className="text-yellow-500 text-sm">VaR: 2.1%</span>
            </div>
            <AlertTriangle className="w-12 h-12 text-yellow-500" />
          </div>
        </div>
      </div>

      {/* Agent Status and Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="text-xl font-bold mb-4">Agent Performance</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-500" />
                <span>Alpha Research Agent</span>
              </div>
              <span className="text-green-500">98% Accuracy</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-purple-500" />
                <span>Risk Management Agent</span>
              </div>
              <span className="text-green-500">99% Uptime</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-yellow-500" />
                <span>Execution Agent</span>
              </div>
              <span className="text-green-500">100% Success Rate</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="text-xl font-bold mb-4">Active Strategies</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                <span>Momentum Strategy</span>
              </div>
              <span className="text-green-500">+1.8% Today</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-500" />
                <span>Mean Reversion</span>
              </div>
              <span className="text-red-500">-0.3% Today</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-purple-500" />
                <span>Statistical Arbitrage</span>
              </div>
              <span className="text-green-500">+0.9% Today</span>
            </div>
          </div>
        </div>
      </div>

      {/* Risk Metrics */}
      <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
        <h2 className="text-xl font-bold mb-4">Risk Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-gray-400">Value at Risk (95%)</p>
            <p className="text-2xl font-bold">2.1%</p>
          </div>
          <div>
            <p className="text-gray-400">Sharpe Ratio</p>
            <p className="text-2xl font-bold">1.85</p>
          </div>
          <div>
            <p className="text-gray-400">Beta</p>
            <p className="text-2xl font-bold">0.75</p>
          </div>
        </div>
      </div>
    </div>
  );
};