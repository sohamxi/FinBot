import { Agent } from 'crewai';

export class BaseAgent extends Agent {
  constructor(config: any) {
    super({
      allowDelegation: true,
      verbose: true,
      ...config
    });
  }

  async analyze(data: any): Promise<any> {
    throw new Error('analyze method must be implemented');
  }

  async execute(task: any): Promise<any> {
    throw new Error('execute method must be implemented');
  }
}