from langchain.tools import BaseTool
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any

class MarketDataTool(BaseTool):
    name = "market_data_tool"
    description = "Fetches market data for given symbols"

    def _run(self, symbols: List[str], interval: str = "1d", period: str = "1mo") -> Dict[str, Any]:
        try:
            data = {}
            for symbol in symbols:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period=period, interval=interval)
                data[symbol] = hist.to_dict('records')
            return {"status": "success", "data": data}
        except Exception as e:
            return {"status": "error", "error": str(e)}

class TechnicalAnalysisTool(BaseTool):
    name = "technical_analysis_tool"
    description = "Performs technical analysis on market data"

    def _run(self, data: pd.DataFrame) -> Dict[str, Any]:
        try:
            indicators = self._calculate_indicators(data)
            signals = self._generate_signals(indicators)
            return {
                "status": "success",
                "indicators": indicators.tail().to_dict('records'),
                "signals": signals
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def _calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        # Technical indicators
        df['SMA_20'] = df['Close'].rolling(window=20).mean()
        df['SMA_50'] = df['Close'].rolling(window=50).mean()
        df['RSI'] = self._calculate_rsi(df['Close'])
        df['MACD'], df['Signal'] = self._calculate_macd(df['Close'])
        df['BB_upper'], df['BB_middle'], df['BB_lower'] = self._calculate_bollinger_bands(df['Close'])
        return df

    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    def _calculate_macd(self, prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> tuple:
        exp1 = prices.ewm(span=fast, adjust=False).mean()
        exp2 = prices.ewm(span=slow, adjust=False).mean()
        macd = exp1 - exp2
        signal_line = macd.ewm(span=signal, adjust=False).mean()
        return macd, signal_line

    def _calculate_bollinger_bands(self, prices: pd.Series, window: int = 20, num_std: float = 2) -> tuple:
        middle = prices.rolling(window=window).mean()
        std = prices.rolling(window=window).std()
        upper = middle + (std * num_std)
        lower = middle - (std * num_std)
        return upper, middle, lower

class RiskManagementTool(BaseTool):
    name = "risk_management_tool"
    description = "Calculates and monitors risk metrics"

    def _run(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        try:
            risk_metrics = {
                "var": self._calculate_var(portfolio),
                "sharpe_ratio": self._calculate_sharpe_ratio(portfolio),
                "max_drawdown": self._calculate_max_drawdown(portfolio),
                "position_limits": self._check_position_limits(portfolio)
            }
            return {"status": "success", "metrics": risk_metrics}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def _calculate_var(self, portfolio: Dict[str, Any], confidence: float = 0.95) -> float:
        returns = pd.Series(portfolio.get("returns", []))
        return returns.quantile(1 - confidence)

    def _calculate_sharpe_ratio(self, portfolio: Dict[str, Any], risk_free_rate: float = 0.02) -> float:
        returns = pd.Series(portfolio.get("returns", []))
        excess_returns = returns - (risk_free_rate / 252)  # Daily risk-free rate
        return np.sqrt(252) * excess_returns.mean() / excess_returns.std()

    def _calculate_max_drawdown(self, portfolio: Dict[str, Any]) -> float:
        equity_curve = pd.Series(portfolio.get("equity_curve", []))
        rolling_max = equity_curve.expanding().max()
        drawdowns = equity_curve / rolling_max - 1
        return drawdowns.min()