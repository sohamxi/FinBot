from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from agents.ceo_agent import CEOAgent
from agents.data_acquisition_agent import DataAcquisitionAgent

app = FastAPI(title="ASM Wealth Trading System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize agents
ceo_agent = CEOAgent()
data_agent = DataAcquisitionAgent()

@app.get("/")
async def root():
    return {"message": "ASM Wealth Trading System API"}

@app.get("/market-data/{symbol}")
async def get_market_data(symbol: str, interval: str = "1d", period: str = "1mo"):
    data = await data_agent.execute({
        "symbols": [symbol],
        "interval": interval,
        "period": period
    })
    return data

@app.post("/analyze")
async def analyze_strategy(data: dict):
    analysis = await ceo_agent.analyze(data)
    return analysis

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)