from crewai import Crew, Task
from typing import List, Dict, Any
from datetime import datetime
from ..agents.executive.ceo_agent import CEOAgent
from ..agents.executive.cto_agent import CTOAgent
from ..agents.development.data_preprocessing_agent import DataPreprocessingAgent
from ..agents.development.order_management_agent import OrderManagementAgent
from ..agents.research.alpha_research_agent import AlphaResearchAgent
from ..agents.research.strategy_selection_agent import StrategySelectionAgent
from ..agents.infrastructure.monitoring_agent import MonitoringAgent
from ..tools.market_tools import MarketDataTool, TechnicalAnalysisTool, RiskManagementTool

class TradingCrew:
    def __init__(self):
        # Initialize tools
        self.market_data_tool = MarketDataTool()
        self.technical_analysis_tool = TechnicalAnalysisTool()
        self.risk_management_tool = RiskManagementTool()
        
        # Initialize executive agents
        self.ceo_agent = CEOAgent()
        self.cto_agent = CTOAgent()
        
        # Initialize development agents
        self.data_preprocessing_agent = DataPreprocessingAgent()
        self.order_management_agent = OrderManagementAgent()
        
        # Initialize research agents
        self.alpha_research_agent = AlphaResearchAgent()
        self.strategy_selection_agent = StrategySelectionAgent()
        
        # Initialize infrastructure agents
        self.monitoring_agent = MonitoringAgent()
        
    def create_crew(self) -> Crew:
        crew = Crew(
            agents=[
                self.ceo_agent.agent,
                self.cto_agent.agent,
                self.data_preprocessing_agent.agent,
                self.order_management_agent.agent,
                self.alpha_research_agent.agent,
                self.strategy_selection_agent.agent,
                self.monitoring_agent.agent
            ],
            tasks=self._create_tasks(),
            verbose=True
        )
        return crew
    
    def _create_tasks(self) -> List[Task]:
        tasks = [
            Task(
                description="Preprocess and clean market data",
                agent=self.data_preprocessing_agent.agent,
                tools=[self.market_data_tool]
            ),
            Task(
                description="Analyze market conditions and identify trading opportunities",
                agent=self.alpha_research_agent.agent,
                tools=[self.market_data_tool, self.technical_analysis_tool]
            ),
            Task(
                description="Select optimal trading strategies",
                agent=self.strategy_selection_agent.agent,
                tools=[self.technical_analysis_tool]
            ),
            Task(
                description="Manage order execution",
                agent=self.order_management_agent.agent,
                tools=[self.risk_management_tool]
            ),
            Task(
                description="Monitor system performance and generate alerts",
                agent=self.monitoring_agent.agent,
                tools=[self.market_data_tool, self.risk_management_tool]
            ),
            Task(
                description="Review technical infrastructure",
                agent=self.cto_agent.agent,
                tools=[self.market_data_tool]
            ),
            Task(
                description="Make final trading decisions",
                agent=self.ceo_agent.agent,
                tools=[self.risk_management_tool]
            )
        ]
        return tasks
    
    async def execute_trading_cycle(self) -> Dict[str, Any]:
        crew = self.create_crew()
        result = await crew.run()
        
        return {
            "cycle_result": result,
            "timestamp": datetime.now().isoformat(),
            "status": "completed"
        }