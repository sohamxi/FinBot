import yfinance as yf
from typing import Dict, Any, List
from .base_agent import BaseAgent

class DataAcquisitionAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Data Acquisition Agent",
            role="Market Data Collector",
            goal="Retrieve high-quality market data from multiple sources"
        )
    
    async def fetch_market_data(
        self, 
        symbols: List[str], 
        interval: str = "1d",
        period: str = "1mo"
    ) -> Dict[str, Any]:
        try:
            data = {}
            for symbol in symbols:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period=period, interval=interval)
                data[symbol] = hist.to_dict('records')
            
            return {
                "status": "success",
                "data": data,
                "metadata": {
                    "symbols": symbols,
                    "interval": interval,
                    "period": period
                }
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        # Implement data quality analysis
        return {
            "data_quality": "high",
            "coverage": "100%",
            "latency": "0.5ms"
        }
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        return await self.fetch_market_data(
            symbols=task.get("symbols", []),
            interval=task.get("interval", "1d"),
            period=task.get("period", "1mo")
        )