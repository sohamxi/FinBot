from abc import ABC, abstractmethod
from typing import Any, Dict, List
from crewai import Agent
from langchain.tools import BaseTool

class BaseAgent(ABC):
    def __init__(self, name: str, role: str, goal: str, tools: List[BaseTool] = None):
        self.agent = Agent(
            name=name,
            role=role,
            goal=goal,
            backstory="Expert AI agent in algorithmic trading",
            tools=tools or [],
            allow_delegation=True,
            verbose=True
        )
    
    @abstractmethod
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        pass