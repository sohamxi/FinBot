from typing import Dict, Any, List
from ..base_agent import BaseAgent
from ...tools.market_tools import TechnicalAnalysisTool

class StrategySelectionAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Strategy Selection Agent",
            role="Strategy Evaluator",
            goal="Select optimal trading strategies based on market conditions",
            tools=[TechnicalAnalysisTool()]
        )
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        strategies = self._evaluate_strategies(data)
        return {
            "selected_strategies": self._rank_strategies(strategies),
            "performance_metrics": self._calculate_strategy_metrics(strategies)
        }
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        if task.get("type") == "strategy_selection":
            return await self._select_strategy(task)
        return {"status": "error", "message": "Unknown task type"}
    
    def _evaluate_strategies(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        return [
            {
                "name": "Momentum",
                "performance": 0.85,
                "risk_score": 0.6
            },
            {
                "name": "Mean Reversion",
                "performance": 0.75,
                "risk_score": 0.4
            }
        ]